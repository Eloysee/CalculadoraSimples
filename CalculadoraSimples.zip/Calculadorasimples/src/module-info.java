/**
 * 
 */
/**
 * 
 */
module Calculadorasimples {
}